document.addEventListener('DOMContentLoaded', ()=>{
  // active nav
  const links = document.querySelectorAll('.navbar a');
  const path = location.pathname.split('/').pop() || 'index.html';
  links.forEach(a=>{ if(a.getAttribute('href')===path) a.style.textDecoration='underline'});
  // gallery click
  document.querySelectorAll('.gallery-grid img').forEach(img=> img.addEventListener('click', ()=> window.open(img.src, '_blank')));
  // form validation (id=formMain)
  const form = document.getElementById('formMain');
  if(form) form.addEventListener('submit', function(e){ e.preventDefault(); const n=this.querySelector('input[name=name]').value.trim(); const em=this.querySelector('input[name=email]').value.trim(); const m=this.querySelector('textarea[name=message]').value.trim(); if(!n||!em||!m){ alert('Please fill all fields.'); return; } alert('Form validated (demo).'); this.reset(); });
  // back to top
  const toTop = document.getElementById('toTop'); if(toTop) toTop.addEventListener('click', ()=> window.scrollTo({top:0, behavior:'smooth'}));
});
const toTop = document.getElementById("toTop");

window.addEventListener("scroll", () => {
  toTop.style.display = window.scrollY > 200 ? "inline-block" : "none";
});

toTop.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});
